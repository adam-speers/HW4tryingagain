﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Dim myObjectCreator As New ObjectCreator
        myObjectCreator.CreateObjectsAndLists()

    End Sub
    '***********************************************************************************************************************************************************************************
    Public Sub Query(choice As String)
        '
        'ADS: This sub runs the query on the dataset using LINQ commands
        Dim userJobInput = From y In Department.DepartmentList
                           Where y.DepartmentName = choice
                           Join x In Job.JobList On x.ID Equals y.ID
                           Join z In Discipline.DisciplineList On x.ID Equals z.ID
                           Select x.CompanyName, x.Salary, x.Location


        'ADS: Now we display the results in a message box using the string format method
        'ADS: Constructs the column headings
        Dim displayQuery = String.Format("{0,-12}, {1}, {1,-6}, {2}, {2,-8}", "Company Name", "vbTab", "Salary", vbTab, "Location", vbTab, vbCrLf)
        'ADS: Now we construct each row of the query
        For Each record In userJobInput
            displayQuery &= String.Format("{0,-12}, {1}, {1,-6}, {2}, {2,-8}", record.CompanyName, vbTab, record.Salary, vbTab, record.Location, vbTab, vbCrLf)
        Next

        MessageBox.Show(displayQuery)

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim userChoice As String
        userChoice = CSng(TextBox1.Text)

        Query(userChoice)

    End Sub
End Class

﻿Public Class ObjectCreator

    Public Sub CreateObjectsAndLists()

        Dim myConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\HW4_SP19.mdb"
        Dim mySQL As String
        Dim tableName As String
        Dim myDataSet As New DataSet
        Dim myDBMS As New DBMS

        tableName = "Job"
        mySQL = "SELECT * FROM " & tableName

        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myJob As New Job

            myJob.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myJob.CompanyName = myDataSet.Tables(tableName).Rows(rowNumber)("Company Name")
            myJob.JobTitle = myDataSet.Tables(tableName).Rows(rowNumber)("Job Title")
            myJob.DisciplineRequired = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Required")
            myJob.Location = myDataSet.Tables(tableName).Rows(rowNumber)("Location")
            myJob.Salary = myDataSet.Tables(tableName).Rows(rowNumber)("Salary")
            myJob.NumberOfOpenings = myDataSet.Tables(tableName).Rows(rowNumber)("Number Of Openings")


            Job.JobList.Add(myJob)
        Next

        tableName = "Discipline"
        mySQL = "SELECT * FROM " & tableName

        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myDiscipline As New Discipline

            myDiscipline.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myDiscipline.DisciplineDescription = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Description")

            Discipline.DisciplineList.Add(myDiscipline)
        Next

        tableName = "Department"
        mySQL = "SELECT * FROM " & tableName

        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myDepartment As New Department

            myDepartment.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myDepartment.DepartmentName = myDataSet.Tables(tableName).Rows(rowNumber)("Department Name")
            myDepartment.DisciplineOffered = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Offered")

            Department.DepartmentList.Add(myDepartment)
        Next


    End Sub

End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblADSEnterDepartment = New System.Windows.Forms.Label()
        Me.txtADSUserInput = New System.Windows.Forms.TextBox()
        Me.btnADSFindJobs = New System.Windows.Forms.Button()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'lblADSEnterDepartment
        '
        Me.lblADSEnterDepartment.AutoSize = True
        Me.lblADSEnterDepartment.BackColor = System.Drawing.SystemColors.Control
        Me.lblADSEnterDepartment.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblADSEnterDepartment.Location = New System.Drawing.Point(11, 50)
        Me.lblADSEnterDepartment.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblADSEnterDepartment.Name = "lblADSEnterDepartment"
        Me.lblADSEnterDepartment.Size = New System.Drawing.Size(229, 18)
        Me.lblADSEnterDepartment.TabIndex = 0
        Me.lblADSEnterDepartment.Text = "Enter Your Department Name"
        '
        'txtADSUserInput
        '
        Me.txtADSUserInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.875!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtADSUserInput.Location = New System.Drawing.Point(253, 47)
        Me.txtADSUserInput.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtADSUserInput.Name = "txtADSUserInput"
        Me.txtADSUserInput.Size = New System.Drawing.Size(136, 24)
        Me.txtADSUserInput.TabIndex = 1
        '
        'btnADSFindJobs
        '
        Me.btnADSFindJobs.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.875!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnADSFindJobs.Location = New System.Drawing.Point(411, 37)
        Me.btnADSFindJobs.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnADSFindJobs.Name = "btnADSFindJobs"
        Me.btnADSFindJobs.Size = New System.Drawing.Size(113, 43)
        Me.btnADSFindJobs.TabIndex = 2
        Me.btnADSFindJobs.Text = "Find Jobs"
        Me.btnADSFindJobs.UseVisualStyleBackColor = True
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.Location = New System.Drawing.Point(127, 93)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(262, 139)
        Me.RichTextBox1.TabIndex = 3
        Me.RichTextBox1.Text = "Choices include:" & Global.Microsoft.VisualBasic.ChrW(10) & "ACCT" & Global.Microsoft.VisualBasic.ChrW(10) & "BIT" & Global.Microsoft.VisualBasic.ChrW(10) & "CS" & Global.Microsoft.VisualBasic.ChrW(10) & "FIN" & Global.Microsoft.VisualBasic.ChrW(10) & "ICE" & Global.Microsoft.VisualBasic.ChrW(10) & "MKTG"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(546, 244)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.btnADSFindJobs)
        Me.Controls.Add(Me.txtADSUserInput)
        Me.Controls.Add(Me.lblADSEnterDepartment)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Form1"
        Me.Text = "Job Finder"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblADSEnterDepartment As Label
    Friend WithEvents txtADSUserInput As TextBox
    Friend WithEvents btnADSFindJobs As Button
    Friend WithEvents RichTextBox1 As RichTextBox
End Class

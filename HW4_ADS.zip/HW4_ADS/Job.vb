﻿Public Class Job

    Public Shared Property JobList As New List(Of Job)

    Public Property ID As Long
    Public Property CompanyName As String
    Public Property JobTitle As String
    Public Property DisciplineRequired As Long
    Public Property Location As String
    Public Property Salary As Decimal
    Public Property NumberOfOpenings As Long

    Public Sub New()


    End Sub

End Class
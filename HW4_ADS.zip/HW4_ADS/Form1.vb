﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnADSFindJobs.Click
        '
        'ADS: Converts user's input in textbox to the query criteria
        Dim userChoice As String
        userChoice = CStr(txtADSUserInput.Text)

        Query(userChoice)

    End Sub


    '***********************************************************************************************************************************************************************************
    Public Sub Query(choice As String)
        '
        'ADS: This sub runs the query on the dataset using LINQ commands
        Dim userJobInput = From y In Department.DepartmentList
                           Where y.DepartmentName = choice
                           Join x In Job.JobList On x.ID Equals y.ID
                           Join z In Discipline.DisciplineList On x.ID Equals z.ID
                           Select x.CompanyName, x.Salary, x.Location


        'ADS: Now we display the results in a message box using the string format method
        'ADS: Constructs the column headings
        Dim displayQuery = String.Format("{0,-25} {1} {2,-15} {3} {4,-10} {5}", "Company Name", vbTab, "Salary", vbTab, "Location", vbTab, vbCrLf)
        'ADS: Now we construct each row of the query
        For Each record In userJobInput
            displayQuery &= String.Format("{0,-9} {1} {2,-15} {3} {4,-8} {5}", record.CompanyName, vbTab, record.Salary, vbTab, record.Location, vbTab, vbCrLf)
        Next
        'ADS: Displays message box
        MessageBox.Show(displayQuery)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '
        'ADS: This subroutine calls the object creator that transfers data from the database to the properties of objects

        Dim myObjectCreator As New ObjectCreator
        myObjectCreator.CreateObjectsAndLists()

    End Sub


End Class


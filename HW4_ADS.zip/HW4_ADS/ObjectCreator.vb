﻿Public Class ObjectCreator
    'ADS: This class extracts data from the data set tables and creates objects with properties that correspond to their respective tables
    Public Sub CreateObjectsAndLists()
        'ADS: Initializes my database connection string
        Dim myConnectionString As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\HW4_SP19.mdb"
        '
        'ADS: Defines key variables for the objects needed for the database connection
        Dim mySQL As String
        Dim tableName As String
        Dim myDataSet As New DataSet
        Dim myDBMS As New DBMS
        '
        'ADS: Sets properties of the Jobs objects from the data in the Job table
        tableName = "Jobs"
        mySQL = "SELECT * FROM " & tableName                                'ADS: SQL selects columns from the Jobs table in Access
        myDBMS.RunSQL(tableName, mySQL, myDataSet, myConnectionString)      'ADS: Executes query
        '
        'ADS: Creates objects of the Job class from the data in the Jobs table
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myJob As New Job

            myJob.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myJob.CompanyName = myDataSet.Tables(tableName).Rows(rowNumber)("Company Name")
            myJob.JobTitle = myDataSet.Tables(tableName).Rows(rowNumber)("Job Title")
            myJob.DisciplineRequired = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Required")
            myJob.Location = myDataSet.Tables(tableName).Rows(rowNumber)("Location")
            myJob.Salary = myDataSet.Tables(tableName).Rows(rowNumber)("Salary")
            myJob.NumberOfOpenings = myDataSet.Tables(tableName).Rows(rowNumber)("Number Of Openings")

            Job.JobList.Add(myJob)
        Next
        '
        'ADS: Sets properties of the Discipline objects from the data in the Discipline table
        tableName = "Discipline"
        mySQL = "SELECT * FROM " & tableName                                'ADS: SQL selects columns from the Jobs table in Access
        myDBMS.RunSQL(tableName, mySQL, myDataSet, myConnectionString)      'ADS: Executes query
        '
        'ADS: Creates objects of the Discipline class from the data in the Discipline table
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myDiscipline As New Discipline

            myDiscipline.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myDiscipline.DisciplineDescription = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Description")

            Discipline.DisciplineList.Add(myDiscipline)
        Next
        '
        'ADS: Sets properties of the Department objects from the data in the DepartmentDiscipline table
        tableName = "DepartmentDiscipline"
        mySQL = "SELECT * FROM " & tableName                                'ADS: SQL selects columns from the DepartmentDiscipline table in Access
        myDBMS.RunSQL(tableName, mySQL, myDataSet, myConnectionString)      'ADS: Executes query
        '
        'ADS: Creates objects of the Department class from the data in the DepartmentDiscipline table
        For rowNumber As Integer = 0 To myDataSet.Tables(tableName).Rows.Count - 1
            Dim myDepartment As New Department

            myDepartment.ID = myDataSet.Tables(tableName).Rows(rowNumber)("ID")
            myDepartment.DepartmentName = myDataSet.Tables(tableName).Rows(rowNumber)("Department Name")
            myDepartment.DisciplineOffered = myDataSet.Tables(tableName).Rows(rowNumber)("Discipline Offered")

            Department.DepartmentList.Add(myDepartment)
        Next

    End Sub

End Class
﻿Public Class Discipline

    Public Shared Property DisciplineList As New List(Of Discipline)

    Public Property ID As Long
    Public Property DisciplineDescription

End Class

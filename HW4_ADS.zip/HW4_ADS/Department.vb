﻿Public Class Department

    Public Shared Property DepartmentList As New List(Of Department)

    Public Property ID As Long
    Public Property DepartmentName
    Public Property DisciplineOffered

End Class